package com.jarvis.vision

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineException
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.IBinder

/** Always listening for the word "Jarvis" (on-device, offline). When heard it opens the Jarvis screen. */
class WakeService : Service() {

    companion object {
        @Volatile
        var instance: WakeService? = null
        const val CHANNEL = "jarvis_wake"
        const val ACTION_STOP = "com.jarvis.vision.STOP"
    }

    private var manager: PorcupineManager? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        showForeground("Listening for \"Jarvis\"")
        startListening()
        return START_STICKY
    }

    private fun showForeground(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Jarvis wake word", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, WakeService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Jarvis")
            .setContentText(text)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    private fun startListening() {
        val m = manager
        if (m != null) {
            try { m.start() } catch (e: Exception) { }
            return
        }
        val key = Prefs.key(this)
        if (key.isBlank()) {
            showForeground("Add your Picovoice AccessKey in Jarvis setup")
            return
        }
        try {
            val built = PorcupineManager.Builder()
                .setAccessKey(key)
                .setKeyword(Porcupine.BuiltInKeyword.JARVIS)
                .setSensitivity(0.7f)
                .build(applicationContext, PorcupineManagerCallback { _ -> onWake() })
            manager = built
            built.start()
        } catch (e: PorcupineException) {
            manager = null
            showForeground("Wake word error: " + (e.message ?: "unknown").take(90))
        }
    }

    private fun onWake() {
        pauseListening()
        try {
            ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80).startTone(ToneGenerator.TONE_PROP_ACK, 200)
        } catch (e: Exception) { }
        val i = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            .putExtra("wake", true)
        try { startActivity(i) } catch (e: Exception) { }
    }

    fun pauseListening() {
        try { manager?.stop() } catch (e: Exception) { }
    }

    fun resumeListening() {
        if (manager != null) {
            try { manager?.start() } catch (e: Exception) { }
        } else {
            startListening()
        }
    }

    override fun onDestroy() {
        instance = null
        try {
            manager?.stop()
            manager?.delete()
        } catch (e: Exception) { }
        manager = null
        super.onDestroy()
    }
}
