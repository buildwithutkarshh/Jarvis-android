package com.jarvis.vision

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** One simple screen to set the web address and permissions. */
class SetupActivity : Activity() {
    private lateinit var urlBox: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad * 2, pad, pad)

        fun label(t: String): TextView {
            val v = TextView(this)
            v.text = t
            v.textSize = 15f
            v.setPadding(0, pad / 2, 0, pad / 4)
            return v
        }
        fun button(t: String, f: () -> Unit): Button {
            val b = Button(this)
            b.text = t
            b.isAllCaps = false
            b.setOnClickListener { f() }
            return b
        }

        val title = label("JARVIS setup")
        title.textSize = 22f
        col.addView(title)

        col.addView(label("1. Your Jarvis page address (the GitHub Pages link):"))
        urlBox = EditText(this)
        urlBox.hint = "https://YOURNAME.github.io/REPO/index.html"
        urlBox.setText(Prefs.url(this))
        urlBox.setSingleLine()
        urlBox.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        col.addView(urlBox)

        col.addView(label("2. Wake word: Hey Jarvis (offline, no API key required)."))

        col.addView(label("3. Permissions:"))
        col.addView(button("Allow microphone, camera and notifications") { askRuntime() })
        col.addView(button("Allow display over other apps") { askOverlay() })
        col.addView(button("Battery: do not restrict Jarvis") { askBattery() })

        status = label("")
        col.addView(status)

        col.addView(label("4. Start:"))
        col.addView(button("Save and start listening for \"Hey Jarvis\"") { saveAndStart() })
        col.addView(button("Stop listening") {
            stopService(Intent(this, WakeService::class.java))
            toast("Stopped")
        })
        col.addView(button("Open Jarvis") {
            save()
            startActivity(Intent(this, MainActivity::class.java))
        })

        col.addView(label(
            "On Vivo (Funtouch OS) also do this once, or the phone will close Jarvis in the background:\n" +
            "- Settings > Apps > Special app access > Autostart > Jarvis ON\n" +
            "- Settings > Battery > Background power consumption management > Jarvis > Don't restrict\n" +
            "- Open the recent apps screen and lock the Jarvis card\n" +
            "- App permissions: allow Display on lock screen and Background pop-ups"
        ))

        val scroll = ScrollView(this)
        scroll.addView(col)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun save() {
        Prefs.sp(this).edit()
            .putString("url", urlBox.text.toString().trim())
            .remove("pv")
            .apply()
    }

    private fun saveAndStart() {
        save()
        if (Prefs.url(this).isBlank()) { toast("Enter your Jarvis page address first"); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Allow the microphone first"); return
        }
        startForegroundService(Intent(this, WakeService::class.java))
        toast("Listening. Say \"Hey Jarvis\"")
    }

    private fun askRuntime() {
        val list = ArrayList<String>()
        list.add(Manifest.permission.RECORD_AUDIO)
        list.add(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(list.toTypedArray(), 10)
    }

    private fun askOverlay() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            openDetails()
        }
    }

    private fun askBattery() {
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            openDetails()
        }
    }

    private fun openDetails() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun refresh() {
        fun ok(b: Boolean) = if (b) "OK" else "not yet"
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val cam = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val overlay = Settings.canDrawOverlays(this)
        val pm = getSystemService(PowerManager::class.java)
        val battery = pm.isIgnoringBatteryOptimizations(packageName)
        status.text = "Microphone: " + ok(mic) + "\nCamera: " + ok(cam) +
                "\nDisplay over other apps: " + ok(overlay) + "\nBattery unrestricted: " + ok(battery)
    }

    private fun toast(t: String) {
        Toast.makeText(this, t, Toast.LENGTH_LONG).show()
    }
}
