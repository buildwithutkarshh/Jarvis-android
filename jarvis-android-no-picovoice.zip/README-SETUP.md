# JARVIS Android app - setup guide (Hinglish)

This build uses openWakeWord Android to detect **“Hey Jarvis”** locally on the device. No Picovoice account or AccessKey is required.

## Build APK
1. Upload the extracted project files to your GitHub repository (keep the folder structure).
2. Ensure `.github/workflows/build.yml` is present.
3. Open **Actions** and run the `Build Jarvis APK` workflow (or push a commit).
4. Download the `jarvis-apk` artifact ZIP and extract `app-debug.apk`.

## Install and setup
1. Install `app-debug.apk` on Android 8.0 or later.
2. Open Jarvis and enter your Jarvis webpage URL.
3. Grant microphone and notification permissions.
4. Tap **Save and start listening**. The persistent notification should say it is listening for “Hey Jarvis”.
5. Tap **Open Jarvis** and configure your Gemini key on the webpage if that page requires it.

## Notes
- Wake-word detection runs on-device; internet is not needed for detecting “Hey Jarvis”. Internet is still needed for Gemini/web AI features.
- Android may restrict microphone foreground services depending on OS version, battery settings, and how the service is started. Test screen-off behavior on the target phone.
- The included pre-trained wake-word model is licensed CC BY-NC-SA 4.0; this is suitable for personal, non-commercial use subject to that license. Check the model license before commercial distribution.
- This is a debug APK for personal testing, not a Play Store release.
