package com.jarvis.vision

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

/** Shows your Jarvis web page full screen. "Jarvis" spoken to the phone brings this screen up and starts Live. */
class MainActivity : Activity() {
    private var web: WebView? = null
    private var loaded = false
    private var pendingWake = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = Prefs.url(this)
        if (url.isBlank()) {
            startActivity(Intent(this, SetupActivity::class.java))
            finish()
            return
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val w = WebView(this)
        web = w
        setContentView(w)
        hideBars()

        val s = w.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE

        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, u: String?) {
                loaded = true
                if (pendingWake) {
                    pendingWake = false
                    wake()
                }
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread { request.grant(request.resources) }
            }
        }

        askPermissions()
        pendingWake = intent?.getBooleanExtra("wake", false) == true
        w.loadUrl(url)
    }

    private fun askPermissions() {
        val need = ArrayList<String>()
        for (p in listOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p)
        }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.getBooleanExtra("wake", false) == true) {
            if (loaded) wake() else pendingWake = true
        }
    }

    private fun wake() {
        web?.evaluateJavascript("window.jarvisWake&&window.jarvisWake()", null)
    }

    override fun onStart() {
        super.onStart()
        // The screen owns the microphone while it is open.
        WakeService.instance?.pauseListening()
    }

    override fun onStop() {
        super.onStop()
        WakeService.instance?.resumeListening()
    }

    override fun onResume() {
        super.onResume()
        hideBars()
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        val w = web
        if (w != null && w.canGoBack()) w.goBack() else moveTaskToBack(true)
    }
}
