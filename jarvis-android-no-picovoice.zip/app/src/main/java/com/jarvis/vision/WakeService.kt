package com.jarvis.vision

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.IBinder
import com.openwakeword.OpenWakeWord

/** Always listens locally for "Hey Jarvis" using an on-device ONNX wake-word model. */
class WakeService : Service() {

    companion object {
        @Volatile var instance: WakeService? = null
        const val CHANNEL = "jarvis_wake"
        const val ACTION_STOP = "com.jarvis.vision.STOP"
    }

    private var detector: OpenWakeWord? = null
    private var isPaused = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        showForeground("Listening for \"Hey Jarvis\"")
        startListening()
        return START_STICKY
    }

    private fun showForeground(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Jarvis wake word", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, WakeService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Jarvis")
            .setContentText(text)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else startForeground(1, n)
    }

    private fun startListening() {
        if (isPaused) return
        try {
            if (detector == null) {
                detector = OpenWakeWord.Builder(applicationContext)
                    .setModel(OpenWakeWord.BuiltInModel.HEY_JARVIS)
                    .setThreshold(0.5f)
                    .setDebounceMs(2500L)
                    .build()
            }
            detector?.start { _ -> onWake() }
            showForeground("Listening for \"Hey Jarvis\"")
        } catch (e: Exception) {
            showForeground("Wake-word setup error: " + (e.message ?: "unknown").take(90))
        }
    }

    private fun onWake() {
        pauseListening()
        try { ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80).startTone(ToneGenerator.TONE_PROP_ACK, 200) } catch (_: Exception) { }
        val i = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            .putExtra("wake", true)
        try { startActivity(i) } catch (_: Exception) { }
    }

    fun pauseListening() {
        isPaused = true
        try { detector?.stop() } catch (_: Exception) { }
    }

    fun resumeListening() {
        isPaused = false
        startListening()
    }

    override fun onDestroy() {
        instance = null
        try { detector?.stop(); detector?.release() } catch (_: Exception) { }
        detector = null
        super.onDestroy()
    }
}
