package com.jarvis.vision

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    fun url(c: Context): String = sp(c).getString("url", "") ?: ""
    fun key(c: Context): String = sp(c).getString("pv", "") ?: ""
}
